const width = 1200;
const height = 400;
const margin = { top: 20, right: 30, bottom: 40, left: 50 };

let intervalId = null;
let data = [];

const svg = d3
  .select("#chart")
  .append("svg")
  .attr("width", width + margin.left + margin.right)
  .attr("height", height + margin.top + margin.bottom);

const xScale = d3
  .scaleLinear()
  .domain([0, 1])
  .range([margin.left, width - margin.right]);

const yScale = d3
  .scaleLinear()
  .domain([0, 1])
  .range([height - margin.bottom, margin.top]);

const xAxisGroup = svg
  .append("g")
  .attr("transform", `translate(0,${height - margin.bottom})`);

const yAxisGroup = svg
  .append("g")
  .attr("transform", `translate(${margin.left},0)`);

function updateChart() {
  svg.selectAll("circle")
    .data(data)
    .join("circle")
    .attr("cx", d => xScale(d.x))
    .attr("cy", d => yScale(d.y))
    .attr("r", 2)
    .style("fill", "#4169e1");

  xAxisGroup.call(d3.axisBottom(xScale));
  yAxisGroup.call(d3.axisLeft(yScale));
}

async function loadJSON(url) {
  const response = await fetch(url);
  return await response.json();
}

async function addPoints(file) {
  const newData = await loadJSON(`../data/${file}.json`);
  data = [...data, ...newData];
  updateChart();
}

document.getElementById("add-1000").addEventListener("click", () => {
  addPoints("scenario_1")
});

document.getElementById("add-10000").addEventListener("click", () => {
  addPoints("scenario_2")
});

document.getElementById("add-10000-every-5s").addEventListener("click", () => {
  if (intervalId) return;
  let counter = 1;
  const maxRuns = 4;

  function run() {
    addPoints(`scenario_3_${counter}`);
    counter++;
    if (counter >= maxRuns) {
      clearInterval(intervalId);
      intervalId = null;
    }
  }

  run();
  intervalId = setInterval(run, 5000);
});

document.getElementById("reset").addEventListener("click", () => {
  location.reload();
});