const CHART_WIDTH = 1200;
const CHART_HEIGHT = 400;
const POINT_SIZE = 3;
const MARGIN = { top: 20, right: 30, bottom: 40, left: 50 };

const glCanvas = document.getElementById("gl-canvas");
const labelCanvas = document.getElementById("label-canvas");
const gl = glCanvas.getContext("webgl");
const ctx = labelCanvas.getContext("2d");

let data = [];
let preparedVertices = [];
let intervalId = null;

async function loadJSON(url) {
  const response = await fetch(url);
  return await response.json();
}

async function addPoints(file) {
  const newData = await loadJSON(`../data/${file}.json`)
  data = [...data, ...newData];
  prepareVertices();
  renderPoints();
  renderAxes();
}

function prepareVertices() {
  preparedVertices = [];
  for (let i = 0; i < data.length; i++) {
    const normX = data[i].x;
    const normY = data[i].y;

    const px = MARGIN.left + normX * (CHART_WIDTH - MARGIN.left - MARGIN.right);
    const py = MARGIN.top + (1 - normY) * (CHART_HEIGHT - MARGIN.top - MARGIN.bottom);

    const ndcX = (px / CHART_WIDTH) * 2 - 1;
    const ndcY = (1 - py / CHART_HEIGHT) * 2 - 1;

    preparedVertices.push(ndcX, ndcY);
  }
}

function renderPoints() {
  gl.viewport(0, 0, CHART_WIDTH, CHART_HEIGHT);
  gl.clearColor(1, 1, 1, 1);
  gl.clear(gl.COLOR_BUFFER_BIT);

  const vertexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(preparedVertices), gl.STATIC_DRAW);

  const vsSource = `
    attribute vec2 a_position;
    void main() {
      gl_PointSize = ${POINT_SIZE}.0;
      gl_Position = vec4(a_position, 0, 1);
    }
  `;

  const fsSource = `
    void main() {
      gl_FragColor = vec4(0.1, 0.4, 0.8, 1);
    }
  `;

  const vs = gl.createShader(gl.VERTEX_SHADER);
  gl.shaderSource(vs, vsSource);
  gl.compileShader(vs);

  const fs = gl.createShader(gl.FRAGMENT_SHADER);
  gl.shaderSource(fs, fsSource);
  gl.compileShader(fs);

  const program = gl.createProgram();
  gl.attachShader(program, vs);
  gl.attachShader(program, fs);
  gl.linkProgram(program);
  gl.useProgram(program);

  const posAttrib = gl.getAttribLocation(program, "a_position");
  gl.enableVertexAttribArray(posAttrib);
  gl.vertexAttribPointer(posAttrib, 2, gl.FLOAT, false, 0, 0);

  gl.drawArrays(gl.POINTS, 0, preparedVertices.length / 2);
}

function renderAxes() {
  ctx.clearRect(0, 0, CHART_WIDTH, CHART_HEIGHT);
  ctx.strokeStyle = "#e3e3e3";
  ctx.fillStyle = "#313131";
  ctx.font = "12px sans-serif";
  ctx.textAlign = "right";
  ctx.textBaseline = "middle";

  // Y ось і сітка
  for (let i = 0; i <= 10; i++) {
    const yVal = i / 10;
    const py = MARGIN.top + (1 - yVal) * (CHART_HEIGHT - MARGIN.top - MARGIN.bottom);

    ctx.strokeStyle = (i === 0 || i === 10) ? "#ccc" : "transparent";
    ctx.beginPath();
    ctx.moveTo(MARGIN.left, py);
    ctx.lineTo(CHART_WIDTH - MARGIN.right, py);
    ctx.stroke();

    ctx.fillText(yVal.toFixed(1), MARGIN.left - 5, py);
  }

  // X ось і сітка
  ctx.textAlign = "center";
  ctx.textBaseline = "top";

  for (let i = 0; i <= 10; i++) {
    const xVal = i / 10;
    const px = MARGIN.left + xVal * (CHART_WIDTH - MARGIN.left - MARGIN.right);

    ctx.strokeStyle = (i === 0 || i === 10) ? "#ccc" : "transparent";
    ctx.beginPath();
    ctx.moveTo(px, MARGIN.top);
    ctx.lineTo(px, CHART_HEIGHT - MARGIN.bottom);
    ctx.stroke();

    ctx.fillText(xVal.toFixed(1), px, CHART_HEIGHT - MARGIN.bottom + 5);
  }
}

document.getElementById("add-1000").addEventListener("click", () => {
  addPoints("scenario_1")
});

document.getElementById("add-10000").addEventListener("click", () => {
  addPoints("scenario_2")
});

document.getElementById("add-10000-every-5s").addEventListener("click", () => {
  if (intervalId) return;
  let counter = 1;
  const maxRuns = 4;

  function run() {
    addPoints(`scenario_3_${counter}`);
    counter++;
    if (counter >= maxRuns) {
      clearInterval(intervalId);
      intervalId = null;
    }
  }

  run();
  intervalId = setInterval(run, 5000);
});

document.getElementById("reset").addEventListener("click", () => {
  location.reload();
});
