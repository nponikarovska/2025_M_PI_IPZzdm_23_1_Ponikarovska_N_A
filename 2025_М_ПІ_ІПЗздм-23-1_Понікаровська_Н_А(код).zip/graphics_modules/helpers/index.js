export function generateNormalizedData(count) {
  return Array.from({ length: count }, () => ({
    x: Math.random(),
    y: Math.random()
  }));
}
